<div style="width: 100%; height: auto; float: left; margin-bottom: 5px;">
    <script type="text/javascript">
        kmn_placement = '8c5e53d3a5903ad8e3fa500adef51185';
    </script>
    <script type="text/javascript" src="//cdn.komoona.com/scripts/kmn_sa.js"></script>
</div>
<div class="widget" id="facebook">
    <div class="fb-page" data-href="https://www.facebook.com/Animecentertv" data-width="300" data-height="258"
         data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"
         data-show-posts="false">
        <div class="fb-xfbml-parse-ignore">
            <blockquote cite="https://www.facebook.com/Animecentertv">
                <a href="https://www.facebook.com/Animecentertv">Animecenter.TV Network</a>
            </blockquote>
        </div>
    </div>
</div>
<!--/facebook-->
<div style="width: 100%; height: auto; float: left; margin-bottom: 10px;">
    <script type="text/javascript" src="http://www.evolvenation.com/delivery.js?id=15&size=300x250"></script>
</div>
<div style="width: 100%; height: auto; float: left; margin-bottom: 5px;">
    <script id="cid0020000097531107619" data-cfasync="false" async src="//st.chatango.com/js/gz/emb.js"
            style="width: 300px;height: 450px;">
        {"handle":"animecenterco","arch":"js","styles":{"a":"00AE45","b":100,"c":"FFFFFF","d":"FFFFFF","k":"00AE45","l":"00AE45","m":"00AE45","n":"FFFFFF","p":"10.35","q":"00AE45","r":100,"t":0,"surl":0,"allowpm":0,"fwtickm":1}}
    </script>
</div>
<div style="width: 100%; height: auto; float: left; margin-bottom: 10px;">
</div>
</div>